package com.evergent.corejava.Collections.map;

import java.util.HashMap;

public class HashMapDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap mymap=new HashMap();
		mymap.put(100,"Lahari");
		mymap.put(2000,"Vishista");
		mymap.put(300,"HArsha");
		mymap.put(100,"Revanth");
		mymap.put(null,"Dimpu");
		mymap.put(700,null);
		mymap.put(600,null);
		mymap.put(3000,5654);
		System.out.println(mymap);
		

	}

}
