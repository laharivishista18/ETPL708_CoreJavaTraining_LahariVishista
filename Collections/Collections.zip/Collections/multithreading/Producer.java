package com.evergent.corejava.multithreading;

public class Producer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
