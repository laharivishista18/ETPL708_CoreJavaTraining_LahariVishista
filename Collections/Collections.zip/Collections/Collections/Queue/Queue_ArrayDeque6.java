package com.evergent.corejava.Collections.Queue;

import java.util.ArrayDeque;

public class Queue_ArrayDeque6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayDeque<String> pq=new ArrayDeque<>();
		pq.add("lahari");
		pq.add("vishista");
		pq.add("Harsha");
		pq.add("Revanth");
		pq.add("Bhanu");
		pq.add("Chandu");
		System.out.println(pq);
		System.out.println(pq.peek());

	}

}
